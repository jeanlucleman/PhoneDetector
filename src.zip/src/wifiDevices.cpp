#include "wifiDevices.h"

ClsColWifiDevices::ClsColWifiDevices(String _fileName)
  {
    fileName=_fileName;
    arrayNewMac="";
    rssiThreshold = -80;
    countDevices=0;
  }
bool ClsColWifiDevices::checkFreeSpace()
  {
    return (countDevices<NMAXWIFIDEVICES);
  }

wifiDeviceType * ClsColWifiDevices::item(int i)
  {
    Serial.printf("Item = %d\n",i);
    return  &wifiDevices[i];
  }
wifiDeviceType * ClsColWifiDevices::item(String mac)
  {
    bool found=false;
    int i=0;
    Serial.println("item");
    if(countDevices>0)
      {
            
        do
          {
            Serial.print(i);
            Serial.print(" ");
            if(wifiDevices[i].mac==mac)
              {
                Serial.printf("Found: %s at position %d\n",mac.c_str(),i);
                found=true;
                return item(i);
              }  
            i++;
          } while(!found and i!=countDevices);
          }

    Serial.printf("Creation d'un nouveau device en position %d et mac = %s\n",i,mac.c_str());
    wifiDevices[i].mac=mac;
    countDevices++;
    return  &wifiDevices[i];
  }


wifiDeviceType * ClsColWifiDevices::item(String mac)
  {
    bool found=false;
    int i=0;
    Serial.println("item");
    if(countDevices>0)
      {
            
        do
          {
            Serial.print(i);
            Serial.print(" ");
            if(wifiDevices[i].mac==mac)
              {
                Serial.printf("Found: %s at position %d\n",mac.c_str(),i);
                found=true;
                return item(i);
              }  
            i++;
          } while(!found and i!=countDevices);
          }

    Serial.printf("Creation d'un nouveau device en position %d et mac = %s\n",i,mac.c_str());
    wifiDevices[i].mac=mac;
    countDevices++;
    return  &wifiDevices[i];
  }

void ClsColWifiDevices::sort()
  {

  }
void ClsColWifiDevices::save()
  {
    File file = getFile("w");
  }
void ClsColWifiDevices::read()
  {

  }


File ClsColWifiDevices::getFile(const char* mode)
  {
    File myFile;
    if(mode=="r")
      {
        myFile = SD.open(fileName + ".txt", FILE_READ);
      }
    else
      {
        myFile = SD.open(fileName + ".txt", FILE_WRITE);
      }
    return myFile;
  }